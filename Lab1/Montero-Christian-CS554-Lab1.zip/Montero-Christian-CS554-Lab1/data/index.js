const taskData = require("./taskActions")

module.exports = {
    tasks: taskData
}